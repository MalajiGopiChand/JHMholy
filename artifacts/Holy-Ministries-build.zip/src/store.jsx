import React,{createContext,useContext,useEffect,useRef,useState} from 'react';
import {EmailAuthProvider,onAuthStateChanged,reauthenticateWithCredential,signInWithEmailAndPassword,signOut,updatePassword} from 'firebase/auth';
import {doc,getDoc,onSnapshot} from 'firebase/firestore';
import {auth,db,call} from './firebase';
import {normalizePhone,phoneAlias} from '../shared/domain';
const Context=createContext();
export const useStore=()=>useContext(Context);
const blank=()=>({students:[],teachers:[],attendance:[],points:[],stories:[],schedules:[],announcements:[],places:[],classes:[],attendanceDays:[],auditLogs:[]});
export function Provider({children}){
 const[user,setUser]=useState(null),[profile,setProfile]=useState(null),[loading,setLoading]=useState(true),[dataLoading,setDataLoading]=useState(false),[data,setData]=useState(blank),[error,setError]=useState('');
 const generation=useRef(0),identity=useRef(null),access=useRef(false),request=useRef(0),authGeneration=useRef(0);
 const operational=!!profile&&(profile.role==='ADMIN'?profile.active===true:profile.approvalStatus==='approved'&&!profile.phoneChangePending);
 identity.current=user?.uid;access.current=operational;
 useEffect(()=>onAuthStateChanged(auth,async u=>{const version=++authGeneration.current;++generation.current;setUser(u);setProfile(null);setData(blank());setError('');setDataLoading(false);if(!u){setLoading(false);return;}setLoading(true);try{const token=await u.getIdTokenResult();if(version!==authGeneration.current)return;setProfile({id:u.uid,role:token.claims.admin===true?'ADMIN':'TEACHER',resolved:false});}catch(e){if(version===authGeneration.current){setError(e.message);setLoading(false);}}}),[]);
 useEffect(()=>{if(!user||!profile?.role)return;const uid=user.uid,role=profile.role;return onSnapshot(doc(db,role==='ADMIN'?'admins':'teachers',uid),s=>{if(auth.currentUser?.uid!==uid)return;const value=s.exists()?{...s.data(),id:s.id,role,resolved:true}:{id:uid,role,active:false,approvalStatus:'pending',resolved:true};const allowed=role==='ADMIN'?value.active===true:value.approvalStatus==='approved'&&!value.phoneChangePending;if(!allowed){++generation.current;access.current=false;setData(blank());}setProfile(value);setLoading(false);},e=>{++generation.current;access.current=false;setData(blank());setProfile(p=>({...p,resolved:true,active:false,approvalStatus:'disabled'}));setError(e.message);setLoading(false);});},[user?.uid,profile?.role]);
 async function refresh(){if(!access.current)return;const uid=identity.current,version=generation.current,ticket=++request.current;try{const result=await call('snapshot');if(uid===identity.current&&version===generation.current&&access.current&&ticket===request.current){setData({...blank(),...result});setError('');}}catch(e){if(uid===identity.current&&version===generation.current){setError(e.message);if(['functions/permission-denied','functions/unauthenticated'].includes(e.code))setData(blank());}}finally{if(uid===identity.current&&version===generation.current)setDataLoading(false);}}
 const scopeKey=JSON.stringify(profile?.allowedPlaceIds||[]);
 useEffect(()=>{++generation.current;setData(blank());if(!operational){setDataLoading(false);return;}setDataLoading(true);refresh();const timer=setInterval(refresh,15000);const unsubscribe=onSnapshot(doc(db,'sync','changes'),refresh,e=>{setError(e.message);setData(blank());});return()=>{++generation.current;clearInterval(timer);unsubscribe();};},[operational,user?.uid,scopeKey]);
 async function refreshProfile(){if(!auth.currentUser)return;const s=await getDoc(doc(db,profile.role==='ADMIN'?'admins':'teachers',auth.currentUser.uid));if(s.exists())setProfile({...s.data(),id:s.id,role:profile.role,resolved:true});}
 async function login(role,identifier,password){await signInWithEmailAndPassword(auth,role==='ADMIN'?identifier.trim():phoneAlias(identifier),password);}
 async function register(values){await call('registerTeacher',{...values,phone:normalizePhone(values.phone)});await login('TEACHER',values.phone,values.password);}
 async function logout(){++generation.current;access.current=false;setData(blank());setProfile(null);setError('');await signOut(auth);}
 async function mutate(action,payload={}){if(!navigator.onLine)throw new Error('You are offline. Reconnect before saving.');const result=await call(action,payload);await refresh();return result;}
 async function reauthenticate(password){if(!auth.currentUser||!profile?.phone)throw new Error('Sign in again to update your account.');await reauthenticateWithCredential(auth.currentUser,EmailAuthProvider.credential(phoneAlias(profile.phone),password));await auth.currentUser.getIdToken(true);}
 async function changeOwnPhone(phone,password){await reauthenticate(password);await call('updateOwnPhone',{phone:normalizePhone(phone)});await logout();}
 async function changeOwnPassword(currentPassword,newPassword){await reauthenticate(currentPassword);await updatePassword(auth.currentUser,newPassword);}
 return <Context.Provider value={{profile,loading,dataLoading,data,error,operational,login,register,logout,mutate,refresh,refreshProfile,changeOwnPhone,changeOwnPassword}}>{children}</Context.Provider>;
}
