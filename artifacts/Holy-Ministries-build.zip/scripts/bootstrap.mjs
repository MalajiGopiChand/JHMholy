import {createRequire} from 'node:module';
const require=createRequire(new URL('../functions/package.json',import.meta.url));
const {initializeApp,applicationDefault}=require('firebase-admin/app');
const {getAuth}=require('firebase-admin/auth');
const {getFirestore}=require('firebase-admin/firestore');
const emulator=!!process.env.FIREBASE_AUTH_EMULATOR_HOST;
const projectId=process.env.GCLOUD_PROJECT||'jhmholy';
if(emulator&&projectId!=='demo-holy-ministries')throw new Error('Emulator bootstrap must target demo-holy-ministries.');
initializeApp(emulator?{projectId}:{projectId,credential:applicationDefault()});
const email=process.env.ADMIN_EMAIL,password=process.env.ADMIN_INITIAL_PASSWORD;
if(!email||!password||password.length<8)throw new Error('Set server-only ADMIN_EMAIL and ADMIN_INITIAL_PASSWORD (at least 8 characters).');
const auth=getAuth(),db=getFirestore();let user;
try{user=await auth.getUserByEmail(email);const existing=await db.doc('admins/'+user.uid).get();if(!existing.exists||existing.data().bootstrapSource!=='holy-ministries-v1')throw new Error('This email already exists outside this bootstrap. No roles or passwords were changed. Review ownership and use a separate administrator email.');console.log('Administrator already bootstrapped. Password and claims unchanged.');}
catch(e){if(e.code!=='auth/user-not-found')throw e;user=await auth.createUser({email,password,displayName:'Ministry Admin'});try{await auth.setCustomUserClaims(user.uid,{admin:true});await db.doc('admins/'+user.uid).create({fullName:'Ministry Admin',role:'ADMIN',active:true,bootstrapSource:'holy-ministries-v1',createdAt:new Date().toISOString()});}catch(err){await auth.deleteUser(user.uid);throw err;}console.log('Administrator created successfully.');}
console.log('Administrator ready. Add your actual places and classes in Settings. No ministry records were seeded.');
